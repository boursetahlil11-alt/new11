package com.kalamyab.game

import android.content.Context
import android.media.MediaPlayer
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.ui.graphics.Color

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {

    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var player: MediaPlayer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        tts = TextToSpeech(this, this)

        val prefs = getSharedPreferences("progress", Context.MODE_PRIVATE)
        val startIndex = prefs.getInt("index", 0).coerceIn(0, items.size - 1)
        val startLang = if (prefs.getString("lang", "EN") == "FA") Lang.FA else Lang.EN

        setContent {
            MaterialTheme(
                colorScheme = lightColorScheme(
                    primary = Orange,
                    onPrimary = Color.White,
                    background = Sand,
                    onBackground = Ink,
                    surface = Paper,
                    onSurface = Ink
                )
            ) {
                GameScreen(
                    startIndex = startIndex,
                    startLang = startLang,
                    speak = { id, text, lang -> speak(id, text, lang) },
                    onProgress = { i, l ->
                        prefs.edit().putInt("index", i).putString("lang", l.name).apply()
                    }
                )
            }
        }
    }

    override fun onInit(status: Int) {
        ttsReady = status == TextToSpeech.SUCCESS
    }

    // 1) a recorded file in assets/audio (fa_apple.m4a, en_apple.mp3, ...) is used if it exists
    // 2) otherwise the phone's own text-to-speech engine is used, slowly
    private fun speak(id: String, text: String, lang: Lang) {
        if (playRecording(id, lang)) return
        val engine = tts
        if (engine == null || !ttsReady) {
            toast("Voice engine is not ready yet")
            return
        }
        val result = engine.setLanguage(lang.locale)
        if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
            toast(
                if (lang == Lang.FA) "این گوشی صدای فارسی ندارد؛ فایل صوتی ضبط‌شده لازم است"
                else "English voice is not installed on this phone"
            )
            return
        }
        engine.setSpeechRate(if (lang == Lang.EN) 0.65f else 0.8f)
        engine.setPitch(1.0f)
        preferFemaleVoice(engine, lang)
        engine.speak(text, TextToSpeech.QUEUE_FLUSH, null, "word")
    }

    private fun playRecording(id: String, lang: Lang): Boolean {
        val code = if (lang == Lang.FA) "fa" else "en"
        for (ext in listOf("ogg", "mp3", "m4a", "wav")) {
            val path = "audio/${code}_${id}.$ext"
            try {
                val fd = assets.openFd(path)
                try {
                    player?.release()
                    val mp = MediaPlayer()
                    mp.setDataSource(fd.fileDescriptor, fd.startOffset, fd.length)
                    mp.setOnCompletionListener { m ->
                        m.release()
                        if (player === m) player = null
                    }
                    mp.prepare()
                    mp.start()
                    player = mp
                } finally {
                    fd.close()
                }
                return true
            } catch (e: Exception) {
                // file missing or unreadable: try the next extension
            }
        }
        return false
    }

    private fun preferFemaleVoice(engine: TextToSpeech, lang: Lang) {
        try {
            val candidates = engine.voices?.filter {
                it.locale.language == lang.locale.language &&
                    !it.isNetworkConnectionRequired &&
                    it.features?.contains("notInstalled") != true
            }
            val female = candidates?.firstOrNull { it.name.contains("female", ignoreCase = true) }
            if (female != null) engine.setVoice(female)
        } catch (e: Exception) {
            // keep the phone's default voice
        }
    }

    private fun toast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    }

    override fun onDestroy() {
        player?.release()
        player = null
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}
