package com.kalamyab.game

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.absoluteOffset
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.random.Random
import kotlinx.coroutines.delay

// ---------- Colors: warm orange, leaf green, golden light, dark chocolate ----------
internal val Sand = Color(0xFFFFEBD0)
internal val Orange = Color(0xFFF28C28)
internal val Ink = Color(0xFF3B2314)
internal val Paper = Color(0xFFFFFBF4)
private val Leaf = Color(0xFF3F8F55)
private val Gold = Color(0xFFFFC857)
private val Wrong = Color(0xFFC0392B)

@Composable
fun GameScreen(
    startIndex: Int,
    startLang: Lang,
    speak: (String, String, Lang) -> Unit,
    onProgress: (Int, Lang) -> Unit
) {
    var lang by remember { mutableStateOf(startLang) }
    var index by remember { mutableIntStateOf(startIndex) }

    val item = items[index]
    val word = item.word(lang)
    val n = word.length
    val isFa = lang == Lang.FA
    val dir = if (lang.rtl) LayoutDirection.Rtl else LayoutDirection.Ltr
    val haptic = LocalHapticFeedback.current

    var letters by remember(lang, index) { mutableStateOf(shuffleLetters(word)) }
    var chain by remember(lang, index) { mutableStateOf(listOf<Int>()) }
    var solved by remember(lang, index) { mutableStateOf(false) }
    var wrong by remember(lang, index) { mutableStateOf(false) }

    fun show(c: Char): String = if (lang == Lang.EN) c.uppercaseChar().toString() else c.toString()

    fun onChainChange(c: List<Int>) {
        if (solved) return
        if (c.size > chain.size) haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
        chain = c
        wrong = false
    }

    fun onRelease(c: List<Int>) {
        if (solved) return
        if (c.size < 2 && n >= 2) {
            chain = emptyList()
            return
        }
        val attempt = c.map { letters[it] }.joinToString("")
        if (c.size == n && attempt == word) solved = true else wrong = true
    }

    fun reshuffle() {
        if (solved) return
        letters = shuffleLetters(word)
        chain = emptyList()
        wrong = false
    }

    fun hint() {
        if (solved) return
        var k = 0
        while (k < chain.size && letters[chain[k]] == word[k]) k++
        val base = chain.take(k)
        if (base.size >= n) return
        val need = word[base.size]
        val ti = letters.indices.firstOrNull { it !in base && letters[it] == need } ?: return
        val next = base + ti
        chain = next
        wrong = false
        if (next.size == n) solved = true
    }

    LaunchedEffect(wrong) {
        if (wrong) {
            delay(700)
            chain = emptyList()
            wrong = false
        }
    }
    LaunchedEffect(solved) {
        if (solved) speak(item.en, word, lang)
    }
    LaunchedEffect(index, lang) {
        onProgress(index, lang)
    }

    BoxWithConstraints(Modifier.fillMaxSize()) {
        val w = maxWidth
        val h = maxHeight
        val pictureSize = minOf(150.dp, h * 0.19f)
        val wheelSize = minOf(w - 24.dp, h * 0.40f)
        val slotSize = minOf(56.dp, (w - 32.dp - 5.dp * (n - 1)) / n)

        Backdrop()

        Column(
            modifier = Modifier
                .fillMaxSize()
                .systemBarsPadding()
                .padding(horizontal = 16.dp, vertical = 10.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Box(
                    Modifier
                        .shadow(4.dp, RoundedCornerShape(20.dp))
                        .clip(RoundedCornerShape(20.dp))
                        .background(Ink)
                        .padding(horizontal = 14.dp, vertical = 8.dp)
                ) {
                    Text(
                        "${index + 1} / ${items.size}",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Lang.values().forEach { l -> LangChip(l, l == lang) { lang = l } }
                }
            }

            Spacer(Modifier.height(14.dp))
            PictureBubble(item.emoji, pictureSize, solved)
            Spacer(Modifier.height(16.dp))

            CompositionLocalProvider(LocalLayoutDirection provides dir) {
                Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    for (pos in 0 until n) {
                        val ch = chain.getOrNull(pos)?.let { letters[it] }
                        Box(
                            modifier = Modifier
                                .size(slotSize)
                                .shadow(if (ch != null) 4.dp else 0.dp, RoundedCornerShape(12.dp))
                                .clip(RoundedCornerShape(12.dp))
                                .background(
                                    when {
                                        ch == null -> Color(0x55FFF3DD)
                                        solved -> Leaf
                                        wrong -> Wrong
                                        else -> Gold
                                    }
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            if (ch != null) {
                                Text(
                                    show(ch),
                                    fontSize = (slotSize.value * 0.5f).sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (solved || wrong) Color.White else Ink
                                )
                            }
                        }
                    }
                }
            }

            Spacer(Modifier.height(10.dp))

            val message = when {
                solved -> if (isFa) "آفرین!" else "Well done!"
                wrong -> if (isFa) "دوباره امتحان کن" else "Try again"
                else -> if (isFa) "انگشتت را روی حروف بکش" else "Swipe across the letters"
            }
            Box(
                Modifier
                    .clip(RoundedCornerShape(14.dp))
                    .background(Paper)
                    .padding(horizontal = 14.dp, vertical = 6.dp)
            ) {
                Text(
                    message,
                    color = if (wrong) Wrong else if (solved) Leaf else Ink,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            if (solved) {
                Spacer(Modifier.height(12.dp))
                CompositionLocalProvider(LocalLayoutDirection provides dir) {
                    Text(word, fontSize = 40.sp, fontWeight = FontWeight.Bold, color = Ink)
                }
                Spacer(Modifier.height(10.dp))
                val otherLang = if (isFa) Lang.EN else Lang.FA
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    ActionButton("🔊 " + (if (isFa) "تلفظ" else "Listen")) {
                        speak(item.en, word, lang)
                    }
                    ActionButton("🔊 " + item.other(lang)) {
                        speak(item.en, item.other(lang), otherLang)
                    }
                }
                Spacer(Modifier.weight(1f))
                ActionButton(if (isFa) "بعدی ›" else "Next ›", primary = true, wide = true) {
                    index = (index + 1) % items.size
                }
            } else {
                Spacer(Modifier.weight(1f))
                LetterWheel(
                    letters = letters,
                    chain = chain,
                    enabled = !wrong,
                    display = { show(it) },
                    onChain = { onChainChange(it) },
                    onRelease = { onRelease(it) },
                    sizeDp = wheelSize
                )
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    ActionButton(if (isFa) "بُر زدن" else "Shuffle") { reshuffle() }
                    ActionButton(if (isFa) "راهنما" else "Hint") { hint() }
                }
            }
            Spacer(Modifier.height(6.dp))
        }

        Confetti(active = solved, modifier = Modifier.fillMaxSize())
    }
}

@Composable
fun LetterWheel(
    letters: List<Char>,
    chain: List<Int>,
    enabled: Boolean,
    display: (Char) -> String,
    onChain: (List<Int>) -> Unit,
    onRelease: (List<Int>) -> Unit,
    sizeDp: Dp
) {
    val density = LocalDensity.current
    val sizePx = with(density) { sizeDp.toPx() }
    val n = letters.size
    val tileDp = when {
        n >= 8 -> 46.dp
        n == 7 -> 50.dp
        else -> 56.dp
    }
    val tilePx = with(density) { tileDp.toPx() }
    val ringPx = with(density) { 10.dp.toPx() }
    val radius = sizePx / 2f - tilePx / 2f - ringPx
    val centers = remember(n, sizePx, tilePx) {
        List(n) { i ->
            val a = -Math.PI / 2.0 + 2.0 * Math.PI * i / n
            Offset(
                sizePx / 2f + (radius * cos(a)).toFloat(),
                sizePx / 2f + (radius * sin(a)).toFloat()
            )
        }
    }
    var finger by remember { mutableStateOf<Offset?>(null) }
    val chainCallback by rememberUpdatedState(onChain)
    val releaseCallback by rememberUpdatedState(onRelease)

    Box(
        modifier = Modifier
            .size(sizeDp)
            .pointerInput(letters, centers, enabled) {
                if (!enabled) return@pointerInput
                awaitEachGesture {
                    val down = awaitFirstDown()
                    val live = mutableListOf<Int>()

                    fun hit(p: Offset): Int {
                        val limit = tilePx * 0.62f
                        for (i in centers.indices) {
                            if ((p - centers[i]).getDistance() <= limit) return i
                        }
                        return -1
                    }

                    fun handle(p: Offset) {
                        val hitIndex = hit(p)
                        if (hitIndex < 0) return
                        if (live.size >= 2 && live[live.size - 2] == hitIndex) {
                            live.removeAt(live.size - 1)
                            chainCallback(live.toList())
                        } else if (hitIndex !in live) {
                            live.add(hitIndex)
                            chainCallback(live.toList())
                        }
                    }

                    finger = down.position
                    handle(down.position)
                    while (true) {
                        val event = awaitPointerEvent()
                        val change = event.changes.firstOrNull { it.id == down.id } ?: break
                        if (!change.pressed) break
                        change.consume()
                        finger = change.position
                        handle(change.position)
                    }
                    finger = null
                    releaseCallback(live.toList())
                }
            }
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val r = size.minDimension / 2f
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(Color(0xFF7A5234), Color(0xFF3B2314)),
                    center = Offset(size.width / 2f, size.height / 2f),
                    radius = r
                ),
                radius = r
            )
            drawCircle(Gold, radius = r - 3.dp.toPx(), style = Stroke(width = 6.dp.toPx()))
            val pts = chain.map { centers[it] }
            if (pts.isNotEmpty()) {
                val path = Path().apply {
                    moveTo(pts[0].x, pts[0].y)
                    for (k in 1 until pts.size) lineTo(pts[k].x, pts[k].y)
                    finger?.let { lineTo(it.x, it.y) }
                }
                drawPath(
                    path,
                    Gold.copy(alpha = 0.9f),
                    style = Stroke(width = 12.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round)
                )
            }
        }
        letters.forEachIndexed { i, c ->
            val ctr = centers[i]
            val selected = i in chain
            Box(
                modifier = Modifier
                    .absoluteOffset {
                        IntOffset((ctr.x - tilePx / 2f).roundToInt(), (ctr.y - tilePx / 2f).roundToInt())
                    }
                    .size(tileDp)
                    .shadow(5.dp, RoundedCornerShape(14.dp))
                    .clip(RoundedCornerShape(14.dp))
                    .background(if (selected) Gold else Paper),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    display(c),
                    fontSize = if (n >= 8) 22.sp else 26.sp,
                    fontWeight = FontWeight.Bold,
                    color = Ink
                )
            }
        }
    }
}

@Composable
fun PictureBubble(emoji: String, size: Dp, solved: Boolean) {
    val scale by animateFloatAsState(
        targetValue = if (solved) 1.1f else 1f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy),
        label = "picture"
    )
    Box(
        modifier = Modifier
            .size(size)
            .scale(scale)
            .shadow(12.dp, CircleShape)
            .clip(CircleShape)
            .background(Brush.radialGradient(listOf(Color(0xFFFFC27A), Orange)))
            .border(6.dp, Paper, CircleShape),
        contentAlignment = Alignment.Center
    ) {
        Text(emoji, fontSize = (size.value * 0.52f).sp)
    }
}

@Composable
fun Backdrop() {
    Canvas(Modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height
        drawRect(Brush.verticalGradient(listOf(Color(0xFFFFE2B5), Color(0xFFFFB86B), Color(0xFFF28C28))))
        drawCircle(Color(0x44FFF3C4), radius = w * 0.42f, center = Offset(w * 0.86f, h * 0.10f))
        drawCircle(Color(0xFFFFF3C4), radius = w * 0.13f, center = Offset(w * 0.86f, h * 0.10f))
        val far = Path().apply {
            moveTo(0f, h * 0.80f)
            quadraticBezierTo(w * 0.30f, h * 0.68f, w * 0.60f, h * 0.80f)
            quadraticBezierTo(w * 0.85f, h * 0.90f, w, h * 0.76f)
            lineTo(w, h)
            lineTo(0f, h)
            close()
        }
        drawPath(far, Color(0xFF8CC17A))
        val near = Path().apply {
            moveTo(0f, h * 0.88f)
            quadraticBezierTo(w * 0.35f, h * 0.80f, w * 0.70f, h * 0.90f)
            quadraticBezierTo(w * 0.90f, h * 0.95f, w, h * 0.86f)
            lineTo(w, h)
            lineTo(0f, h)
            close()
        }
        drawPath(near, Color(0xFF4F9D5D))
    }
}

private val confettiColors = listOf(
    Color(0xFFFFC857), Color(0xFF3F8F55), Color(0xFFF28C28), Color(0xFFE5486B), Color(0xFF4DA8DA)
)

@Composable
fun Confetti(active: Boolean, modifier: Modifier = Modifier) {
    val t = remember { Animatable(1f) }
    val parts = remember {
        List(36) {
            Triple(Random.nextFloat() * 360f, 0.35f + Random.nextFloat() * 0.65f, confettiColors[it % confettiColors.size])
        }
    }
    LaunchedEffect(active) {
        if (active) {
            t.snapTo(0f)
            t.animateTo(1f, tween(1200))
        } else {
            t.snapTo(1f)
        }
    }
    Canvas(modifier) {
        val p = t.value
        if (p < 1f) {
            val c = Offset(size.width / 2f, size.height * 0.30f)
            parts.forEach { (ang, speed, color) ->
                val a = Math.toRadians(ang.toDouble())
                val r = size.minDimension * 0.85f * speed * p
                val x = c.x + (cos(a) * r).toFloat()
                val y = c.y + (sin(a) * r).toFloat() + 260f * p * p
                drawCircle(color.copy(alpha = 1f - p), radius = 9f * (1f - 0.5f * p), center = Offset(x, y))
            }
        }
    }
}

@Composable
fun ActionButton(text: String, primary: Boolean = false, wide: Boolean = false, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        modifier = (if (wide) Modifier.fillMaxWidth(0.75f) else Modifier)
            .shadow(6.dp, RoundedCornerShape(16.dp)),
        shape = RoundedCornerShape(16.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = if (primary) Leaf else Ink,
            contentColor = Color.White
        ),
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 12.dp)
    ) {
        Text(text, fontSize = 17.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun LangChip(l: Lang, selected: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .shadow(4.dp, RoundedCornerShape(20.dp))
            .clip(RoundedCornerShape(20.dp))
            .background(if (selected) Ink else Paper)
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 8.dp)
    ) {
        Text(
            l.label,
            color = if (selected) Color.White else Ink,
            fontWeight = FontWeight.Bold,
            fontSize = 15.sp
        )
    }
}
